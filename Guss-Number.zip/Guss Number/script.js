'use strict';

displayMassage('Start guessing...');
document.querySelector('.guess').value = 0;
let secretNumber = Math.trunc(Math.random() * 20 + 1);

let score = 20;
document.querySelector('.score').textContent = score;
let highscore = 0;

document.querySelector('.check').addEventListener('click', function () {
  let guessNumber = Number(document.querySelector('.guess').value);

  if (!guessNumber) {
    displayMassage('No Number ❌');
  }

  if (secretNumber !== guessNumber) {
    if (score > 1) {
      displayMassage(
        secretNumber > guessNumber
          ? 'Your Number Is Low 📉'
          : 'Your Number Is High 📈'
      );
      score--;
      document.querySelector('.score').textContent = score;
    } else {
      displayMassage('You Lose The Game 💔');
      score = 0;
      document.querySelector('.score').textContent = score;
    }
  }

  // High Number
  // else if (myNumber > secretNumber) {
  //    if ( score > 1 ) {
  //        document.querySelector('.message').textContent = 'Your Number Is High 📈';
  //        score--;
  //        document.querySelector('.score').textContent = score;
  //    }
  //    else{
  //        document.querySelector('.message').textContent = 'You Lose The Game 💔';
  //        score = 0;
  //        document.querySelector('.score').textContent = score;
  //    }
  // }
  // Low Number
  // else if (myNumber < secretNumber) {
  //    if (score > 1) {
  //        document.querySelector('.message').textContent = 'Your Number Is Low 📉';
  //        score--;
  //        document.querySelector('.score').textContent = score;
  //    }
  //    else{
  //        document.querySelector('.message').textContent = 'You Lose The Game 💔;
  // score = 0;
  //        document.querySelector('.score').textContent = score;
  //    }
  // }

  // Win
  else if (secretNumber === guessNumber) {
    displayMassage('Corect Your Number ✅');
    document.querySelector('body').style.backgroundColor = 'green';
    document.querySelector('.number').style.width = '30rem';

    if (score > highscore) {
      highscore = score;
      document.querySelector('.highscore').textContent = highscore;
    }
  }
});

// Again
document.querySelector('.again').addEventListener('click', function () {
  score = 0;
  document.querySelector('.score').textContent = score;
  secretNumber = Math.trunc(Math.random() * 20 + 1);
  document.querySelector('body').style.backgroundColor = '#222';
  displayMassage('Start guessing...');
  document.querySelector('.number').style.width = '15rem';
  document.querySelector('.guess').value = '';
});

function displayMassage(message) {
  document.querySelector('.message').textContent = message;
}
